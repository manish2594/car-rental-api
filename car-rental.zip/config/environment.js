module.exports = {
  port: 2000,
  dbUrl: "mongodb://localhost:27017/rental"
};
